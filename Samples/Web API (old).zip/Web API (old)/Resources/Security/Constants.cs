﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Resources.Security
{
    public static class AppClaimTypes
    {
        public const string ReportsTo = "http://samples.thinktecture.com/claims/reportsto";
    }
}
