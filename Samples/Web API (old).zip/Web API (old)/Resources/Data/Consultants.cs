﻿using System.Collections.Generic;

namespace Resources
{
    public class Consultants : List<Consultant>
    { }
}
