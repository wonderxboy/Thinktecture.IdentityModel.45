﻿using System.Windows;

namespace IdSrvJSNotifyClient
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
